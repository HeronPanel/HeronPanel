# HeronPanel

A native-process Node.js/Express + WebSocket server panel built around the supplied frontend.

## Requirements

- Debian/Linux recommended
- Node.js 18.17+
- A system user dedicated to running the panel
- Runtime programs used by hosted servers (for example `node`, `java`) installed separately

## Install

```bash
cd HeronPanel
npm install
export JWT_SECRET="$(openssl rand -hex 48)"
export ADMIN_PASSWORD='replace-with-a-strong-password'
export ADMIN_USERNAME='admin'
export ADMIN_EMAIL='admin@example.com'
npm start
```

Open `http://SERVER_IP:3000/`.

The first startup creates the administrator only when `Users/users_db.json` is empty and `ADMIN_PASSWORD` is set. Do not run the panel as root.

## Server execution model

Every server gets `Servers/<server_id>/`. Its `server.json`, runtime files, and `runtime.log` live there. Processes are spawned with `child_process.spawn()` and `shell:false`; shell metacharacters are rejected from configured commands.

The normal user "Create Server" flow initializes a real Node.js runtime (`server.js`) that listens on its allocated local port. Administrators can create servers with another executable/argument command, provided the runtime and files already exist in that server directory.

Stop sends `stop` to stdin first, then SIGINT/SIGTERM/SIGKILL if necessary. Restart performs the same stop sequence before spawning a fresh process.

## Production notes

- Put the panel behind HTTPS (reverse proxy such as nginx/Caddy).
- Set a persistent `JWT_SECRET` and strong admin password through the environment.
- Run under a dedicated unprivileged Linux account with ownership of `Users/`, `Servers/`, and the application directory.
- Restrict the server host's firewall to the ports you actually need.
- Back up `Users/`, `Servers/`, and `settings.json`.
- The panel deliberately does not provide a general shell: the WebSocket console writes to the selected server process stdin only.
- If you allow administrators to configure arbitrary server executables, treat administrator access as host-level privilege.

## systemd

Copy `heronpanel.service.example` to `/etc/systemd/system/heronpanel.service`, edit the user/path/environment values, then:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now heronpanel
sudo systemctl status heronpanel
```

## Minecraft provisioning

The panel now supports real Paper downloads through PaperMC's downloads API and real Spigot builds through Spigot BuildTools. Creation requires explicit EULA acceptance, detects installed Java, applies `-Xms/-Xmx` RAM allocation, creates `server.properties`, and allocates the server port. PaperMC recommends stable builds and a descriptive User-Agent; Spigot distributes Spigot through BuildTools rather than a direct server-JAR download.

### Discord OAuth2
Set these environment variables before starting the panel:

```bash
export DISCORD_CLIENT_ID=...
export DISCORD_CLIENT_SECRET=...
export DISCORD_REDIRECT_URI=https://panel.example.com/api/auth/discord/callback
export DISCORD_SCOPES='identify email'
```

Register the exact callback URL in the Discord Developer Portal. The login uses Discord's OAuth2 authorization-code flow with a random `state` value, then links the Discord account to the local HeronPanel user record.

Discord docs: https://docs.discord.com/developers/topics/oauth2
Paper downloads docs: https://docs.papermc.io/misc/downloads-service/
Spigot BuildTools: https://www.spigotmc.org/wiki/buildtools/


## v3 management features
- File manager: browse, create, edit, upload, download, rename, delete within each server root.
- Backups: tar.gz create/download/restore/delete under `Backups/`.
- Cron schedules: start/stop/restart/backup/command using `node-cron`; persisted in `schedules.json`.
- Player manager: list, OP/DEOP, kick, ban/unban, whitelist and server messages.
- Startup/resources: Java path, JAR, JVM flags, RAM, CPU limit. On Linux, CPU enforcement uses `cpulimit` when installed; otherwise the configured CPU limit is retained but not enforced.
- Install dependency with `npm install` after extraction.

## v4 production hardening
- Async Minecraft installation jobs: `POST /api/servers/install`, poll `/api/servers/install/:jobId`.
- Per-user resource quotas: servers, RAM, disk, CPU; admin can edit limits from Admin > Users.
- Audit log at `audit.log` with admin endpoint `GET /api/admin/audit`.
- API-wide rate limiting plus auth rate limiting.
- WebSocket authentication timeout and optional `ALLOWED_ORIGIN` origin restriction.
- Backup restore validates TAR member paths before extraction.
- CPU enforcement uses Linux `cpulimit` when installed; otherwise the configured limit is not enforced at the OS level.
- Disk quota is enforced on uploads/writes where applicable.

### Recommended production environment
Set `JWT_SECRET` explicitly to a long random secret. For browser deployment behind a reverse proxy, set `ALLOWED_ORIGIN` to the exact HTTPS origin, for example `https://panel.example.com`.

For CPU enforcement on Debian, install the package if desired:
```bash
sudo apt update && sudo apt install -y cpulimit
```
For HTTPS, put Nginx/Caddy in front of HeronPanel and keep the Node process bound to localhost (`HOST=127.0.0.1`).


## Production v5
- Per-server collaborator permissions: console, start, stop, restart, files, backups, schedules, players, startup.
- Automatic crash recovery with configurable restart attempts and delay.
- Admin API for assigning/removing server permissions.
- Configure recovery in `settings.json` or Admin settings API.
- For public deployment, place Nginx/HTTPS in front of HeronPanel and set `ALLOWED_ORIGIN` to the exact HTTPS origin.

## v5.1 Operations UI
- Admin Monitoring view with 5-second refresh
- Admin per-server collaborator permissions UI
- Crash Recovery controls in Admin Settings
- Server cards link directly to Permissions management


## Production v5.2 deployment

1. Create a dedicated Linux user and install Node.js 18+ and Git.
2. Install dependencies with `npm install`.
3. Set a strong `JWT_SECRET`, `ADMIN_PASSWORD`, and production `ALLOWED_ORIGIN` in systemd.
4. Keep HeronPanel bound to localhost when using Nginx: `HOST=127.0.0.1`.
5. Copy `heronpanel.service.example` to `/etc/systemd/system/heronpanel.service`, review paths and permissions, then run `systemctl daemon-reload && systemctl enable --now heronpanel`.
6. Copy `nginx-heronpanel.conf.example` to an Nginx site, replace `panel.example.com`, configure TLS, and reload Nginx.
7. For CPU enforcement on Debian, install `cpulimit`; the panel reports whether it is available.
8. Back up `Users/`, `Servers/`, `Backups/`, `settings.json`, `schedules.json`, `Metrics/`, `Crashes/`, and `audit.log`.

### Monitoring
The admin monitoring page exposes system load, memory, running-server count, per-server CPU/RAM/disk, process I/O, TPS/MSPT when present in the Minecraft log, health state, and recent crash history. Metrics history is kept as a rolling 180-sample window per server.
