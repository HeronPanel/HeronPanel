
(() => {
  async function settings() { try { const r=await fetch('/api/settings'); return r.ok?r.json():null; } catch{return null;} }
  function apply(s) {
    if(!s)return;
    document.title=document.title.replace(/HeronPanel|Server Panel|Sign In|Create Account|My Account|Admin Panel|Server Dashboard/g,s.panelName);
    document.querySelectorAll('[data-panel-name]').forEach(e=>e.textContent=s.panelName);
    const logo=s.useCustomImage&&s.logoPath?s.logoPath:'/logo.png';
    document.querySelectorAll('img[src="logo.png"],img[data-panel-logo]').forEach(i=>i.src=logo);
    document.querySelectorAll('link[rel="icon"]').forEach(i=>i.href=logo);
  }
  window.Heron={settings};
  document.addEventListener('DOMContentLoaded',async()=>{
    apply(await settings());
    const proto=location.protocol==='https:'?'wss://':'ws://';
    try { const ws=new WebSocket(proto+location.host+'/ws'); ws.onmessage=e=>{try{const m=JSON.parse(e.data);if(m.type==='settings')apply(m.settings)}catch{}}; } catch {}
  });
})();
