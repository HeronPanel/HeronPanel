
'use strict';

const path = require('path');
const fs = require('fs');
const fsp = fs.promises;
const os = require('os');
const http = require('http');
const crypto = require('crypto');
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pidusage = require('pidusage');
const { WebSocketServer } = require('ws');
const { spawn, spawnSync, execFile } = require('child_process');
const cron = require('node-cron');
const https = require('https');
const httpClient = require('http');

const ROOT = __dirname;
const USERS_DIR = path.join(ROOT, 'Users');
const SERVERS_DIR = path.join(ROOT, 'Servers');
const SETTINGS_FILE = path.join(ROOT, 'settings.json');
const PUBLIC_DIR = path.join(ROOT, 'public');
const BACKUPS_DIR = path.join(ROOT, 'Backups');
const SCHEDULES_FILE = path.join(ROOT, 'schedules.json');
const AUDIT_FILE = path.join(ROOT, 'audit.log');
const METRICS_DIR = path.join(ROOT, 'Metrics');
const CRASH_DIR = path.join(ROOT, 'Crashes');
const JOBS_DIR = path.join(ROOT, 'Jobs');
const SECRET = process.env.JWT_SECRET || (() => {
  const p = path.join(ROOT, '.jwt-secret');
  try { return fs.readFileSync(p, 'utf8').trim(); } catch {}
  const s = crypto.randomBytes(48).toString('hex');
  fs.writeFileSync(p, s, { mode: 0o600 });
  return s;
})();
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ noServer: true });
const processes = new Map(); // serverId -> child
const intentionalStops = new Set();
const restartState = new Map();
const sockets = new Map();   // serverId -> Set<ws>

const DEFAULT_SETTINGS = {
  panelName: 'HeronPanel', logoPath: '/logo.png', useCustomImage: false,
  registrationEnabled: true,
  resources: { maxServersPerUser: 5, maxMemoryMB: 4096, maxDiskMB: 20480, maxCpuPercent: 100 },
  recovery: { autoRestart: true, maxAttempts: 3, delaySeconds: 10 },
  ports: { start: 25565, end: 26500 },
  nodes: [{ id:'local', name:'Local Node', address:'127.0.0.1', location:'localhost',
    ramGB:0, diskGB:0, cores:os.cpus().length, daemonPort:0, local:true }]
};


function minecraftJavaRequirement(version) {
  const m=String(version||'').match(/^(\d+)(?:\.(\d+))?/); if(!m) return 21;
  const a=Number(m[1]), b=Number(m[2]||0);
  if(a>=26) return 25;
  if(a===21 || (a===20 && b>=5)) return 21;
  if(a===20 || a===19 || a===18) return 17;
  if(a===17) return 16;
  if(a===16 && b>=5) return 16;
  if(a===16) return 11;
  if(a>=12) return 11;
  return 8;
}
function detectJava() {
  const r=spawnSync('java',['-version'],{encoding:'utf8'}); const text=(r.stderr||'')+'\n'+(r.stdout||'');
  const m=text.match(/version\s+"(\d+)(?:\.(\d+))?(?:\.(\d+))?/i); let major=null;
  if(m){ major=Number(m[1]); if(major===1) major=Number(m[2]); }
  return {installed:r.status===0, major, raw:text.trim().split('\n')[0]||'java not found'};
}
function safeMcVersion(v){ return /^\d+\.\d+(?:\.\d+)?(?:[-+._a-zA-Z0-9]*)?$/.test(String(v||'')); }
async function fetchJson(url) {
  const r=await fetch(url,{headers:{'User-Agent':'HeronPanel/4.0 (+https://example.invalid)'}}); if(!r.ok) throw new Error(`Remote API ${r.status}`); return r.json();
}
async function downloadTo(url,file) {
  const r=await fetch(url,{headers:{'User-Agent':'HeronPanel/4.0 (+https://example.invalid)'}}); if(!r.ok) throw new Error(`Download failed: HTTP ${r.status}`);
  const buf=Buffer.from(await r.arrayBuffer()); await fsp.writeFile(file,buf); return buf.length;
}
async function paperVersions(){
  const data=await fetchJson('https://fill.papermc.io/v3/projects/paper');
  return [...new Set(Object.values(data.versions||{}).flat())].sort((a,b)=>String(b).localeCompare(String(a),undefined,{numeric:true}));
}
async function paperDownload(version, dir){
  const builds=await fetchJson(`https://fill.papermc.io/v3/projects/paper/versions/${encodeURIComponent(version)}/builds`);
  const stable=Array.isArray(builds)?builds.find(x=>x.channel==='STABLE' && x.downloads?.['server:default']?.url):null;
  if(!stable) throw new Error(`No stable Paper build found for ${version}.`);
  const url=stable.downloads['server:default'].url; await downloadTo(url,path.join(dir,'server.jar'));
  return {build:stable.id, downloadUrl:url};
}
async function spigotBuild(version,dir,emit){
  const bt=path.join(dir,'BuildTools.jar');
  await downloadTo('https://hub.spigotmc.org/jenkins/job/BuildTools/lastSuccessfulBuild/artifact/target/BuildTools.jar',bt);
  const java=detectJava(); if(!java.installed) throw new Error('Java is required for Spigot BuildTools.');
  const git=spawnSync('git',['--version'],{encoding:'utf8'}); if(git.status!==0) throw new Error('Git is required for Spigot BuildTools. Install git first.');
  return await new Promise((resolve,reject)=>{
    const child=spawn('java',['-jar','BuildTools.jar','--rev',version],{cwd:dir,env:{...process.env},shell:false});
    child.stdout.on('data',d=>emit?.(d.toString())); child.stderr.on('data',d=>emit?.(d.toString()));
    child.on('error',reject); child.on('exit',(code)=>{
      if(code!==0) return reject(new Error(`Spigot BuildTools failed with code ${code}.`));
      const jar=path.join(dir,`spigot-${version}.jar`); if(!fs.existsSync(jar)) return reject(new Error('BuildTools finished but Spigot JAR was not found.'));
      fs.renameSync(jar,path.join(dir,'server.jar')); try{fs.unlinkSync(bt)}catch{}; resolve({build:version});
    });
  });
}
function readProperties(file){ const out={}; if(!fs.existsSync(file)) return out; for(const line of fs.readFileSync(file,'utf8').split(/\r?\n/)){ if(!line||line.startsWith('#')) continue; const i=line.indexOf('='); if(i>0) out[line.slice(0,i)]=line.slice(i+1); } return out; }
function writeProperties(file,obj){ const keys=Object.keys(obj); fs.writeFileSync(file,keys.map(k=>`${k}=${String(obj[k]).replace(/\r?\n/g,' ')}`).join('\n')+'\n'); }
function mcCommand(s,cmd){ const c=processes.get(s.id); if(!c) throw new Error('Server is not running.'); c.stdin.write(String(cmd).replace(/[\r\n]/g,'')+'\n'); appendLog(s,`> ${cmd}\n`); }
function discordConfig(){ const d=getSettings().discord||{}; return {enabled:Boolean(process.env.DISCORD_CLIENT_ID||d.clientId) && Boolean(process.env.DISCORD_CLIENT_SECRET||d.clientSecret),clientId:process.env.DISCORD_CLIENT_ID||d.clientId,clientSecret:process.env.DISCORD_CLIENT_SECRET||d.clientSecret,redirectUri:process.env.DISCORD_REDIRECT_URI||d.redirectUri,scopes:process.env.DISCORD_SCOPES||d.scopes||'identify email'}; }
const oauthStates=new Map();
function makeDiscordState(){ const state=crypto.randomBytes(32).toString('hex'); oauthStates.set(state,Date.now()+10*60*1000); return state; }
function consumeDiscordState(state){ const exp=oauthStates.get(state); oauthStates.delete(state); return exp && exp>Date.now(); }
function discordUsername(u){ return String(u.username||u.global_name||`discord_${u.id}`).replace(/[^a-zA-Z0-9_-]/g,'').slice(0,24) || `discord_${u.id}`; }

function ensureDirs() {
  for (const d of [USERS_DIR, SERVERS_DIR, PUBLIC_DIR, BACKUPS_DIR, METRICS_DIR, CRASH_DIR, JOBS_DIR]) fs.mkdirSync(d, { recursive: true });
  if (!fs.existsSync(SETTINGS_FILE)) writeJson(SETTINGS_FILE, DEFAULT_SETTINGS);
  const db = path.join(USERS_DIR, 'users_db.json');
  if (!fs.existsSync(db)) writeJson(db, {users:[]});
  if (!fs.existsSync(SCHEDULES_FILE)) writeJson(SCHEDULES_FILE, {schedules:[]});
}
function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file,'utf8')); } catch { return fallback; }
}
function writeJson(file, data) {
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), {mode:0o600});
  fs.renameSync(tmp, file);
}
function getSettings() {
  const s = readJson(SETTINGS_FILE, DEFAULT_SETTINGS);
  return { ...DEFAULT_SETTINGS, ...s, resources:{...DEFAULT_SETTINGS.resources,...(s.resources||{})},
    recovery:{...DEFAULT_SETTINGS.recovery,...(s.recovery||{})},
    ports:{...DEFAULT_SETTINGS.ports,...(s.ports||{})},
    minecraft:{...DEFAULT_SETTINGS.minecraft,...(s.minecraft||{})},
    discord:{...DEFAULT_SETTINGS.discord,...(s.discord||{})},
    nodes:s.nodes||DEFAULT_SETTINGS.nodes };
}
function saveSettings(s) { writeJson(SETTINGS_FILE, s); broadcast({type:'settings',settings:s}); }
function userDb() { return readJson(path.join(USERS_DIR,'users_db.json'), {users:[]}); }
function saveDb(db) { writeJson(path.join(USERS_DIR,'users_db.json'), db); }
function audit(req, action, details={}) {
  try { fs.appendFileSync(AUDIT_FILE, JSON.stringify({ts:new Date().toISOString(),ip:req?.ip||'',user:req?.user?.sub||'anonymous',action,details})+'\n'); } catch {}
}
function userLimits(u){ const d=u?.limits||{}; const r=getSettings().resources; return {maxServers:Number(d.maxServers||r.maxServersPerUser),maxMemoryMB:Number(d.maxMemoryMB||r.maxMemoryMB),maxDiskMB:Number(d.maxDiskMB||r.maxDiskMB),maxCpuPercent:Number(d.maxCpuPercent||r.maxCpuPercent)}; }
function canManage(req,s){ return req.user.role==='admin'||s.owner===req.user.sub; }
const SERVER_PERMS=['console','start','stop','restart','files','backups','schedules','players','startup'];
function serverPermissions(s, username){ if(s.owner===username) return Object.fromEntries(SERVER_PERMS.map(k=>[k,true])); const p=s.permissions?.[username]||{}; return Object.fromEntries(SERVER_PERMS.map(k=>[k,Boolean(p[k])])); }
function requireServerPerm(req,res,s,perm){ if(req.user.role==='admin'||s.owner===req.user.sub||serverPermissions(s,req.user.sub)[perm]) return true; res.status(403).json({error:`Permission required: ${perm}`}); return false; }
function normalizePermissions(v){ const out={}; for(const k of SERVER_PERMS) out[k]=Boolean(v?.[k]); return out; }
function publicUser(u) { return {username:u.username, fullName:u.fullName, email:u.email, role:u.role, limits:userLimits(u), createdAt:u.createdAt}; }
function safeName(v) { return String(v||'').trim().replace(/[^a-zA-Z0-9 _.-]/g,'').slice(0,64); }
function validUsername(v) { return /^[a-zA-Z0-9_-]{3,32}$/.test(v); }
function validEmail(v) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v); }
function sign(u) { return jwt.sign({sub:u.username, role:u.role}, SECRET, {expiresIn:'12h'}); }
function auth(req,res,next) {
  const h=req.headers.authorization||''; const token=h.startsWith('Bearer ')?h.slice(7):null;
  if(!token) return res.status(401).json({error:'Authentication required'});
  try { req.user=jwt.verify(token,SECRET); next(); } catch { res.status(401).json({error:'Invalid or expired session'}); }
}
function admin(req,res,next){ if(req.user.role!=='admin') return res.status(403).json({error:'Administrator access required'}); next(); }
function findUser(username) { return userDb().users.find(u=>u.username.toLowerCase()===String(username).toLowerCase()); }
function writeUser(u) { const db=userDb(); const i=db.users.findIndex(x=>x.username.toLowerCase()===u.username.toLowerCase()); if(i<0) db.users.push(u); else db.users[i]=u; saveDb(db); writeJson(path.join(USERS_DIR, `${u.username}.json`), u); }
function deleteUserFiles(u) { try { fs.unlinkSync(path.join(USERS_DIR,`${u.username}.json`)); } catch {} }
function getServer(id) {
  if(!/^[a-zA-Z0-9_-]{8,64}$/.test(id)) return null;
  return readJson(path.join(SERVERS_DIR,id,'server.json'), null);
}
function saveServer(s) { writeJson(path.join(SERVERS_DIR,s.id,'server.json'),s); }
function listServers() {
  return fs.readdirSync(SERVERS_DIR,{withFileTypes:true}).filter(x=>x.isDirectory()).map(x=>getServer(x.name)).filter(Boolean);
}
function isOwnerOrAdmin(req,s) { return req.user.role==='admin' || s.owner===req.user.sub; }
function broadcast(msg, filter) {
  const raw=JSON.stringify(msg);
  for (const ws of wss.clients) if(ws.readyState===1 && (!filter || filter(ws))) ws.send(raw);
}
function sendServer(serverId,msg) {
  const set=sockets.get(serverId); if(!set) return;
  const raw=JSON.stringify(msg); for(const ws of set) if(ws.readyState===1) ws.send(raw);
}
function appendLog(s, text) {
  const line=String(text);
  const log=path.join(SERVERS_DIR,s.id,'runtime.log');
  fs.appendFile(log, line.endsWith('\n')?line:line+'\n', ()=>{});
  sendServer(s.id,{type:'output',data:line});
}
function parseCommandLine(input) {
  // Small shell-free tokenizer. Quotes/backslashes are honored; shell metacharacters are rejected.
  const str=String(input||'').trim();
  if(!str || /[;&|`$<>]/.test(str)) throw new Error('Unsafe start command: shell operators are not allowed.');
  const out=[]; let cur='', quote=null, esc=false;
  for(const c of str) {
    if(esc){cur+=c;esc=false;continue}
    if(c==='\\'){esc=true;continue}
    if(quote){ if(c===quote) quote=null; else cur+=c; }
    else if(c==="'"||c==='"') quote=c;
    else if(/\s/.test(c)){if(cur){out.push(cur);cur='';}}
    else cur+=c;
  }
  if(quote||esc) throw new Error('Malformed start command.');
  if(cur) out.push(cur);
  if(!out.length) throw new Error('Start command is required.');
  return out;
}
async function portFree(port) {
  return new Promise(resolve=>{
    const net=require('net'); const s=net.createServer();
    s.once('error',()=>resolve(false)); s.once('listening',()=>s.close(()=>resolve(true))); s.listen(port,'127.0.0.1');
  });
}
async function allocatePort() {
  const s=getSettings(), start=Number(s.ports.start||25565), end=Number(s.ports.end||start+500);
  const used=new Set(listServers().map(x=>x.port));
  for(let p=start;p<=end;p++) if(!used.has(p) && await portFree(p)) return p;
  throw new Error('No free ports available.');
}
function diskUsage(dir) {
  let bytes=0;
  function walk(d){ for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name); if(e.isSymbolicLink()) continue; if(e.isDirectory()) walk(p); else {try{bytes+=fs.statSync(p).size}catch{}}} }
  try{walk(dir)}catch{} return bytes;
}
function formatBytes(n){const u=['B','KB','MB','GB','TB'];let i=0;while(n>=1024&&i<u.length-1){n/=1024;i++}return `${n.toFixed(i?1:0)} ${u[i]}`;}
function readProcIo(pid){
  const out={readBytes:0,writeBytes:0};
  try{for(const line of fs.readFileSync(`/proc/${pid}/io`,'utf8').split(/\n/)){const m=line.match(/^(read_bytes|write_bytes):\s+(\d+)/);if(m)out[m[1]==='read_bytes'?'readBytes':'writeBytes']=Number(m[2]);}}catch{}
  return out;
}
function systemNetwork(){
  let rx=0,tx=0; try{for(const line of fs.readFileSync('/proc/net/dev','utf8').split(/\n/).slice(2)){const i=line.indexOf(':');if(i<0)continue;const v=line.slice(i+1).trim().split(/\s+/);rx+=Number(v[0]||0);tx+=Number(v[8]||0);}}catch{} return {rxBytes:rx,txBytes:tx};
}
function extractMinecraftHealth(s){
  const log=path.join(SERVERS_DIR,s.id,'runtime.log'); let text=''; try{text=fs.readFileSync(log,'utf8').slice(-30000);}catch{}
  const t=[...text.matchAll(/(?:TPS|tps)[^0-9]*(\d+(?:\.\d+)?)/g)].pop();
  const ms=[...text.matchAll(/(?:MSPT|mspt)[^0-9]*(\d+(?:\.\d+)?)/g)].pop();
  const pl=[...text.matchAll(/There are (\d+) of a max of (\d+) players online(?::\s*(.*))?/g)].pop();
  return {tps:t?Number(t[1]):null,mspt:ms?Number(ms[1]):null,players:pl?{online:Number(pl[1]),max:Number(pl[2]),names:String(pl[3]||'').split(',').map(x=>x.trim()).filter(Boolean)}:null};
}
function metricsHistory(s,m){
  const file=path.join(METRICS_DIR,`${s.id}.json`); const arr=readJson(file,[]); arr.push({ts:new Date().toISOString(),cpu:m.cpu,ram:m.ram,disk:m.disk}); while(arr.length>180)arr.shift(); try{writeJson(file,arr)}catch{} return arr;
}
async function metrics(s) {
  const running=processes.get(s.id);
  let cpu=0, ram=0, uptime=0, io={readBytes:0,writeBytes:0};
  if(running && running.pid) { try { const q=await pidusage(running.pid); cpu=q.cpu||0; ram=q.memory||0; uptime=Math.floor(q.elapsed/1000); io=readProcIo(running.pid); } catch {} }
  const disk=diskUsage(path.join(SERVERS_DIR,s.id));
  const m={running:!!running,cpu,ram,ramText:formatBytes(ram),disk,diskText:formatBytes(disk),uptime,pid:running?.pid||null,io,network:systemNetwork(),health:extractMinecraftHealth(s)};
  metricsHistory(s,m); return m;
}
async function stopProcess(s, force=false) {
  const child=processes.get(s.id); if(!child) return true;
  if(!force) {
    try { child.stdin.write('stop\n'); } catch {}
    await new Promise(r=>setTimeout(r,4000));
    if(processes.has(s.id)) try{child.kill('SIGINT')}catch{}
    await new Promise(r=>setTimeout(r,2500));
  }
  if(processes.has(s.id)) try{child.kill('SIGTERM')}catch{}
  await new Promise(r=>setTimeout(r,1000));
  if(processes.has(s.id)) try{child.kill('SIGKILL')}catch{}
  processes.delete(s.id); s.status='offline'; s.pid=null; saveServer(s); sendServer(s.id,{type:'status',status:'offline'}); return true;
}
function recordCrash(s,reason){
  const file=path.join(CRASH_DIR,`${s.id}.json`); const arr=readJson(file,[]); arr.push({ts:new Date().toISOString(),reason}); while(arr.length>100)arr.shift(); writeJson(file,arr); audit(null,'server.crash',{serverId:s.id,reason});
}
function getCrashHistory(s){return readJson(path.join(CRASH_DIR,`${s.id}.json`),[]).slice(-100).reverse();}
async function startProcess(s) {
  if(processes.has(s.id)) return;
  const cfg=startupConfig(s);
  let args=['-Xms'+cfg.memoryMB+'M','-Xmx'+cfg.memoryMB+'M',...cfg.jvmFlags,'-jar',cfg.jar,'--nogui'];
  let cmd=cfg.javaPath;
  if(process.platform!=='win32' && cfg.cpuLimitPercent>0 && cfg.cpuLimitPercent<100){
    const cpulimit=spawnSync('which',['cpulimit'],{encoding:'utf8'});
    if(cpulimit.status===0){ args=['-l',String(Math.max(1,Math.min(100,cfg.cpuLimitPercent))),'--',cmd,...args]; cmd='cpulimit'; }
  }
  const child=spawn(cmd,args,{cwd:serverDirFor(s),env:{...process.env,SERVER_PORT:String(s.port),SERVER_ID:s.id},shell:false,windowsHide:true});
  processes.set(s.id,child); s.status='running'; s.pid=child.pid; s.startedAt=new Date().toISOString(); saveServer(s);
  sendServer(s.id,{type:'status',status:'running',pid:child.pid});
  child.stdout.on('data',d=>appendLog(s,d.toString())); child.stderr.on('data',d=>appendLog(s,d.toString()));
  child.on('error',e=>{appendLog(s,`[process error] ${e.message}`);s.status='crashed';s.pid=null;saveServer(s);processes.delete(s.id);recordCrash(s,`process error: ${e.message}`);sendServer(s.id,{type:'status',status:'crashed'});broadcast({type:'server:update',server:s});});
  child.on('exit',(code,sig)=>{
    appendLog(s,`[process exit] code=${code} signal=${sig||''}`);
    processes.delete(s.id); s.pid=null;
    const manual=intentionalStops.delete(s.id);
    const crashed=code!==0 && !manual; s.status=crashed?'crashed':'offline'; if(crashed)recordCrash(s,`exit code=${code} signal=${sig||''}`); saveServer(s);
    sendServer(s.id,{type:'status',status:s.status}); broadcast({type:'server:update',server:s});
    if(crashed && getSettings().recovery.autoRestart){
      const st=restartState.get(s.id)||{attempts:0};
      if(st.attempts < Number(getSettings().recovery.maxAttempts||3)){
        st.attempts++; restartState.set(s.id,st);
        const delay=Math.max(1,Number(getSettings().recovery.delaySeconds||10))*1000;
        appendLog(s,`[recovery] auto-restart ${st.attempts}/${getSettings().recovery.maxAttempts} in ${delay/1000}s\n`);
        setTimeout(async()=>{try{const fresh=getServer(s.id); if(fresh && !processes.has(fresh.id)) await startProcess(fresh);}catch(e){appendLog(s,`[recovery] failed: ${e.message}\n`)}},delay);
      } else appendLog(s,'[recovery] maximum automatic restart attempts reached.\n');
    } else if(!crashed) restartState.delete(s.id);
  });
  return child;
}

ensureDirs();
const users=userDb();
if(!users.users.length && process.env.ADMIN_PASSWORD) {
  const u={fullName:'Administrator',username:process.env.ADMIN_USERNAME||'admin',email:process.env.ADMIN_EMAIL||'admin@localhost',
    passwordHash:bcrypt.hashSync(process.env.ADMIN_PASSWORD,12),role:'admin',createdAt:new Date().toISOString()};
  writeUser(u); console.log(`Created admin account: ${u.username}`);
} else if(!users.users.length) {
  console.warn('No users exist. Set ADMIN_PASSWORD (and optionally ADMIN_USERNAME/ADMIN_EMAIL) before first production start.');
}

app.disable('x-powered-by');
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:'2mb'}));
app.use('/api/auth/',rateLimit({windowMs:15*60*1000,max:20,standardHeaders:true,legacyHeaders:false}));
app.use('/api/',rateLimit({windowMs:60*1000,max:240,standardHeaders:true,legacyHeaders:false,skip:(req)=>req.path.startsWith('/auth/')}));
app.use(express.static(PUBLIC_DIR,{extensions:['html']}));

app.get('/api/settings',(req,res)=>{const s=getSettings();res.json({...s,discord:{enabled:discordConfig().enabled}})});
app.get('/api/auth/status',(req,res)=>res.json({registrationEnabled:getSettings().registrationEnabled}));

app.post('/api/auth/register',async(req,res)=>{
  const s=getSettings(); if(!s.registrationEnabled) return res.status(403).json({error:'Registration is disabled.'});
  const {fullName,username,email,password}=req.body||{};
  if(!safeName(fullName)||!validUsername(username)||!validEmail(email)||typeof password!=='string'||password.length<8) return res.status(400).json({error:'Name, username, valid email and password (8+ characters) are required.'});
  const db=userDb(); if(db.users.some(u=>u.username.toLowerCase()===username.toLowerCase()||u.email.toLowerCase()===email.toLowerCase())) return res.status(409).json({error:'Username or email is already in use.'});
  const u={fullName:safeName(fullName),username,email:email.toLowerCase(),passwordHash:await bcrypt.hash(password,12),role:'user',createdAt:new Date().toISOString()};
  writeUser(u); audit(req,'auth.register',{username:u.username}); res.status(201).json({message:'Account created.'});
});
app.post('/api/auth/login',async(req,res)=>{
  const {username,password}=req.body||{}; const u=findUser(username||'');
  if(!u || !(await bcrypt.compare(String(password||''),u.passwordHash||''))) return res.status(401).json({error:'Invalid username/email or password.'});
  audit(req,'auth.login',{username:u.username}); res.json({token:sign(u),user:publicUser(u)});
});

app.get('/api/auth/discord', (req,res)=>{
  const d=discordConfig(); if(!d.enabled||!d.redirectUri) return res.status(503).send('Discord login is not configured. Set DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET and DISCORD_REDIRECT_URI.');
  const state=makeDiscordState();
  const u=new URL('https://discord.com/oauth2/authorize'); u.searchParams.set('response_type','code'); u.searchParams.set('client_id',d.clientId); u.searchParams.set('scope',d.scopes); u.searchParams.set('state',state); u.searchParams.set('redirect_uri',d.redirectUri); res.redirect(u.toString());
});
app.get('/api/auth/discord/callback', async (req,res)=>{
  try{
    const d=discordConfig(); if(!d.enabled||!d.redirectUri) throw new Error('Discord OAuth is not configured.');
    if(!consumeDiscordState(String(req.query.state||''))) throw new Error('Invalid or expired OAuth state.');
    const code=String(req.query.code||''); if(!code) throw new Error('Discord authorization code missing.');
    const body=new URLSearchParams({client_id:d.clientId,client_secret:d.clientSecret,grant_type:'authorization_code',code,redirect_uri:d.redirectUri});
    const tr=await fetch('https://discord.com/api/oauth2/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});
    const td=await tr.json(); if(!tr.ok) throw new Error(td.error_description||'Discord token exchange failed.');
    const ur=await fetch('https://discord.com/api/v10/users/@me',{headers:{Authorization:`Bearer ${td.access_token}`}}); const du=await ur.json(); if(!ur.ok) throw new Error('Discord user lookup failed.');
    let u=userDb().users.find(x=>x.discordId===du.id);
    if(!u){
      const base=discordUsername(du); let username=base, n=1; while(findUser(username)) username=(base.slice(0,20)+'_'+n++).slice(0,32);
      const email=du.email && validEmail(du.email) ? du.email.toLowerCase() : `${du.id}@discord.local`;
      const existingEmail=userDb().users.find(x=>x.email===email);
      if(existingEmail) { existingEmail.discordId=du.id; existingEmail.discordUsername=du.username; existingEmail.discordAvatar=du.avatar||null; u=existingEmail; writeUser(u); }
      else { u={fullName:du.global_name||du.username||username,username,email,passwordHash:null,role:'user',createdAt:new Date().toISOString(),discordId:du.id,discordUsername:du.username,discordAvatar:du.avatar||null}; writeUser(u); }
    } else { u.discordUsername=du.username; u.discordAvatar=du.avatar||null; if(du.email&&validEmail(du.email)&&u.email.endsWith('@discord.local')) u.email=du.email.toLowerCase(); writeUser(u); }
    const token=sign(u); const qs=new URLSearchParams({token,user:Buffer.from(JSON.stringify(publicUser(u))).toString('base64url')}); res.redirect('/Login.html#discord='+qs.toString());
  }catch(e){ res.redirect('/Login.html#discord_error='+encodeURIComponent(e.message)); }
});

app.get('/api/user/profile',auth,(req,res)=>{const u=findUser(req.user.sub); if(!u)return res.status(404).json({error:'User not found'}); res.json(publicUser(u));});
app.put('/api/user/profile',auth,async(req,res)=>{
  const old=findUser(req.user.sub); if(!old)return res.status(404).json({error:'User not found'});
  const {fullName,username,email}=req.body||{}; if(!safeName(fullName)||!validUsername(username)||!validEmail(email)) return res.status(400).json({error:'Invalid profile data.'});
  const db=userDb(), clash=db.users.find(u=>u.username.toLowerCase()===username.toLowerCase()||u.email.toLowerCase()===email.toLowerCase());
  if(clash && clash.username.toLowerCase()!==old.username.toLowerCase()) return res.status(409).json({error:'Username or email is already in use.'});
  const updated={...old,fullName:safeName(fullName),username,email:email.toLowerCase()}; 
  const i=db.users.indexOf(old); db.users[i]=updated; saveDb(db); deleteUserFiles(old); writeJson(path.join(USERS_DIR,`${updated.username}.json`),updated);
  for(const sv of listServers()) if(sv.owner===old.username){sv.owner=updated.username;saveServer(sv);}
  res.json({user:publicUser(updated),token:sign(updated)});
});
app.put('/api/user/password',auth,async(req,res)=>{
  const u=findUser(req.user.sub); if(!u)return res.status(404).json({error:'User not found'});
  if(!(await bcrypt.compare(String(req.body.currentPassword||''),u.passwordHash))) return res.status(400).json({error:'Current password is incorrect.'});
  if(String(req.body.newPassword||'').length<8 || req.body.newPassword!==req.body.confirmNewPassword) return res.status(400).json({error:'New passwords must match and be at least 8 characters.'});
  u.passwordHash=await bcrypt.hash(req.body.newPassword,12); writeUser(u); res.json({message:'Password updated.'});
});
app.delete('/api/user/account',auth,async(req,res)=>{
  const u=findUser(req.user.sub); if(!u)return res.status(404).json({error:'User not found'});
  if(!(await bcrypt.compare(String(req.body.password||''),u.passwordHash))) return res.status(400).json({error:'Password is incorrect.'});
  for(const sv of listServers().filter(x=>x.owner===u.username)){await stopProcess(sv,true);fs.rmSync(path.join(SERVERS_DIR,sv.id),{recursive:true,force:true});}
  const db=userDb(); db.users=db.users.filter(x=>x.username!==u.username); saveDb(db); deleteUserFiles(u); res.json({message:'Account deleted.'});
});


// ---- File Manager, Backups, Schedules, Players and Startup/Resources ----
function serverDirFor(s){ return path.join(SERVERS_DIR,s.id); }
function safeRelative(rel=''){
  rel=String(rel).replace(/\\/g,'/');
  if(rel.includes('\0') || path.posix.isAbsolute(rel) || rel.split('/').includes('..')) throw new Error('Invalid path.');
  return rel.replace(/^\/+/,'');
}
function resolveServerPath(s,rel=''){
  const base=serverDirFor(s), target=path.resolve(base,safeRelative(rel));
  if(target!==base && !target.startsWith(base+path.sep)) throw new Error('Path escapes server directory.');
  return target;
}
function schedulesDb(){return readJson(SCHEDULES_FILE,{schedules:[]});}
function saveSchedules(db){writeJson(SCHEDULES_FILE,db);}
const scheduleJobs=new Map();
function refreshScheduleJobs(){
  for(const t of scheduleJobs.values()) try{t.stop()}catch{}
  scheduleJobs.clear();
  for(const job of schedulesDb().schedules){
    if(job.enabled===false || !cron.validate(job.cron)) continue;
    scheduleJobs.set(job.id,cron.schedule(job.cron,()=>runScheduledAction(job)));
  }
}
function runScheduledAction(job){
  const s=getServer(job.serverId); if(!s)return;
  if(job.action==='start') startProcess(s).catch(()=>{});
  else if(job.action==='stop') stopProcess(s).catch(()=>{});
  else if(job.action==='restart') stopProcess(s).then(()=>startProcess(s)).catch(()=>{});
  else if(job.action==='command' && processes.has(s.id)) try{mcCommand(s,String(job.value||''))}catch{}
  else if(job.action==='backup') createBackup(s).catch(()=>{});
}
function createBackup(s){
  return new Promise((resolve,reject)=>{
    const stamp=new Date().toISOString().replace(/[:.]/g,'-');
    const out=path.join(BACKUPS_DIR,`${s.id}-${stamp}.tar.gz`);
    execFile('tar',['-czf',out,'-C',SERVERS_DIR,s.id],{timeout:30*60*1000},err=>{
      if(err)return reject(new Error('Backup failed: '+err.message));
      resolve({name:path.basename(out),size:fs.statSync(out).size,createdAt:new Date().toISOString()});
    });
  });
}
function listBackups(s){
  if(!fs.existsSync(BACKUPS_DIR))return [];
  return fs.readdirSync(BACKUPS_DIR).filter(n=>n.startsWith(s.id+'-')&&n.endsWith('.tar.gz')).map(name=>{
    const st=fs.statSync(path.join(BACKUPS_DIR,name));return {name,size:st.size,createdAt:st.mtime.toISOString()};
  }).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
}
function startupConfig(s){
  return {javaPath:s.javaPath||'java',jar:s.jar||'server.jar',memoryMB:Number(s.memoryMB)||1024,
    jvmFlags:Array.isArray(s.jvmFlags)?s.jvmFlags:[],cpuLimitPercent:Number(s.cpuLimitPercent)||100,
    startCommand:s.startCommand||`java -Xms${Number(s.memoryMB)||1024}M -Xmx${Number(s.memoryMB)||1024}M -jar ${s.jar||'server.jar'} --nogui`};
}
function playerCmd(action,value){
  const v=String(value||'').replace(/[^a-zA-Z0-9_.-]/g,'').slice(0,32);
  const m={kick:`kick ${v}`,ban:`ban ${v}`,pardon:`pardon ${v}`,op:`op ${v}`,deop:`deop ${v}`,
    whitelistAdd:`whitelist add ${v}`,whitelistRemove:`whitelist remove ${v}`};
  return m[action];
}

app.get('/api/servers',auth,async(req,res)=>{
  const items=listServers().filter(s=>req.user.role==='admin'||s.owner===req.user.sub);
  res.json(await Promise.all(items.map(async s=>({...s,metrics:await metrics(s)}))));
});
app.get('/api/servers/:id',auth,async(req,res)=>{
  const s=getServer(req.params.id); if(!s||!isOwnerOrAdmin(req,s))return res.status(404).json({error:'Server not found'});
  res.json({...s,metrics:await metrics(s)});
});
app.get('/api/minecraft/java',auth,(req,res)=>res.json(detectJava()));
app.get('/api/minecraft/versions',auth,async(req,res)=>{try{const type=req.query.type==='spigot'?'spigot':'paper'; const versions=await paperVersions(); res.json({type,versions})}catch(e){res.status(502).json({error:e.message})}});
const installJobs=new Map();
function installJobFile(id){return path.join(JOBS_DIR,id+'.json')}
function saveJob(j){writeJson(installJobFile(j.id),j)}
function getJob(id){return readJson(installJobFile(id),null)}
async function runInstallJob(job, payload, reqUser){
  const owner=findUser(reqUser.sub), settings=getSettings(); if(!owner) throw new Error('User not found');
  const n=Number(payload.memoryMB||settings.minecraft.defaultMemoryMB||1024); const limits=userLimits(owner);
  if(!Number.isInteger(n)||n<512||n>limits.maxMemoryMB) throw new Error(`RAM must be between 512 MB and ${limits.maxMemoryMB} MB.`);
  const required=minecraftJavaRequirement(payload.version), java=detectJava(); if(!java.installed||Number(java.major||0)<required) throw new Error(`Minecraft ${payload.version} requires Java ${required}+; detected ${java.raw}.`);
  if(payload.eulaAccepted!==true) throw new Error('You must accept the Minecraft EULA.'); if(!['paper','spigot'].includes(payload.type)) throw new Error('Unsupported Minecraft software.');
  if(payload.type==='spigot'&&!settings.minecraft.allowSpigot) throw new Error('Spigot creation is disabled by the administrator.'); if(!safeMcVersion(payload.version)) throw new Error('Invalid Minecraft version.');
  const port=await allocatePort(), id=crypto.randomBytes(10).toString('hex'), dir=path.join(SERVERS_DIR,id); fs.mkdirSync(dir,{recursive:true});
  const s={id,name:safeName(payload.name)||`Minecraft ${payload.version}`,owner:owner.username,nodeId:'local',port,type:payload.type,version:payload.version,memoryMB:n,javaMajor:java.major,eulaAccepted:true,jar:'server.jar',startCommand:`java -Xms${n}M -Xmx${n}M -jar server.jar --nogui`,status:'installing',pid:null,createdAt:new Date().toISOString()};
  saveServer(s); audit(reqUser,'server.install.start',{serverId:id}); fs.writeFileSync(path.join(dir,'eula.txt'),'# Generated by HeronPanel\neula=true\n');
  const emit=x=>{appendLog(s,`[installer] ${x}`);job.progressLog=String(x).slice(-2000);saveJob(job)};
  try{job.serverId=id;job.progress=10;saveJob(job); if(payload.type==='paper'){job.progress=35;saveJob(job);await paperDownload(payload.version,dir);}else{job.progress=20;saveJob(job);await spigotBuild(payload.version,dir,emit);} job.progress=90;saveJob(job); const props={motd:s.name,'server-port':String(port),'online-mode':'true','enable-command-block':'false',...(payload.serverProperties&&typeof payload.serverProperties==='object'?payload.serverProperties:{})}; writeProperties(path.join(dir,'server.properties'),props); s.status='offline';s.installedAt=new Date().toISOString();saveServer(s);job.status='complete';job.progress=100;saveJob(job);audit(reqUser,'server.install.complete',{serverId:id});broadcast({type:'server:update',server:s});return s;}
  catch(e){s.status='install_failed';s.error=e.message;saveServer(s);job.status='failed';job.error=e.message;saveJob(job);audit(reqUser,'server.install.failed',{serverId:id,error:e.message});throw e;}
}
app.get('/api/servers/install/:jobId',auth,(req,res)=>{const j=getJob(req.params.jobId);if(!j)return res.status(404).json({error:'Job not found'});if(j.owner!==req.user.sub&&req.user.role!=='admin')return res.status(403).json({error:'Forbidden'});res.json(j)});
app.post('/api/servers/install',auth,async(req,res)=>{
  const job={id:crypto.randomBytes(12).toString('hex'),owner:req.user.sub,status:'queued',progress:0,createdAt:new Date().toISOString(),progressLog:''};saveJob(job);installJobs.set(job.id,job);
  runInstallJob(job,req.body||{},req).then(s=>{job.server=s;installJobs.delete(job.id);saveJob(job)}).catch(e=>{job.error=e.message;installJobs.delete(job.id);saveJob(job)});
  res.status(202).json(job);
});
app.post('/api/servers',auth,async(req,res)=>{
  const {name,type='paper',version,memoryMB,eulaAccepted,serverProperties}=req.body||{};
  const owner=findUser(req.user.sub); if(!owner)return res.status(401).json({error:'User not found'});
  const settings=getSettings(), limits=userLimits(owner), count=listServers().filter(x=>x.owner===owner.username).length;
  if(count>=limits.maxServers)return res.status(400).json({error:'Server limit reached.'});
  const n=Number(memoryMB||settings.minecraft.defaultMemoryMB); if(!Number.isInteger(n)||n<512||n>limits.maxMemoryMB)return res.status(400).json({error:`RAM must be between 512 MB and ${settings.resources.maxMemoryMB} MB.`});
  if(eulaAccepted!==true)return res.status(400).json({error:'You must accept the Minecraft EULA.'});
  if(!['paper','spigot'].includes(type))return res.status(400).json({error:'Unsupported Minecraft software.'});
  if(type==='spigot'&&!settings.minecraft.allowSpigot)return res.status(400).json({error:'Spigot creation is disabled by the administrator.'});
  if(!safeMcVersion(version))return res.status(400).json({error:'Invalid Minecraft version.'});
  const required=minecraftJavaRequirement(version), java=detectJava(); if(!java.installed||Number(java.major||0)<required)return res.status(400).json({error:`Minecraft ${version} requires Java ${required}+; detected ${java.raw}.`});
  const port=await allocatePort(), id=crypto.randomBytes(10).toString('hex'), dir=path.join(SERVERS_DIR,id); fs.mkdirSync(dir,{recursive:true});
  const s={id,name:safeName(name)||`Minecraft ${version}`,owner:owner.username,nodeId:'local',port,type,version,memoryMB:n,javaMajor:java.major,eulaAccepted:true,jar:'server.jar',startCommand:`java -Xms${n}M -Xmx${n}M -jar server.jar --nogui`,status:'installing',pid:null,createdAt:new Date().toISOString()};
  saveServer(s); audit(req,'server.create',{serverId:id,name:s.name,type,version,owner:s.owner}); fs.writeFileSync(path.join(dir,'eula.txt'),'# Generated by HeronPanel\neula=true\n');
  try{
    const emit=x=>appendLog(s,`[installer] ${x}`);
    if(type==='paper') await paperDownload(version,dir); else await spigotBuild(version,dir,emit);
    const props={motd:s.name,'server-port':String(port),'online-mode':'true','enable-command-block':'false',...(serverProperties&&typeof serverProperties==='object'?serverProperties:{})}; writeProperties(path.join(dir,'server.properties'),props);
    s.status='offline'; s.installedAt=new Date().toISOString(); saveServer(s); broadcast({type:'server:update',server:s}); res.status(201).json({...s,metrics:await metrics(s)});
  }catch(e){ s.status='install_failed'; s.error=e.message; saveServer(s); res.status(502).json({error:e.message,serverId:s.id}); }
});
app.post('/api/servers/:id/start',auth,async(req,res)=>{const s=getServer(req.params.id);if(!s||!isOwnerOrAdmin(req,s))return res.status(404).json({error:'Server not found'});if(!requireServerPerm(req,res,s,'start'))return;try{await startProcess(s);audit(req,'server.start',{serverId:s.id});res.json({...s,metrics:await metrics(s)})}catch(e){res.status(400).json({error:e.message})}});
app.post('/api/servers/:id/stop',auth,async(req,res)=>{const s=getServer(req.params.id);if(!s||!isOwnerOrAdmin(req,s))return res.status(404).json({error:'Server not found'});if(!requireServerPerm(req,res,s,'stop'))return;await stopProcess(s);audit(req,'server.stop',{serverId:s.id});res.json({...s,metrics:await metrics(s)})});
app.post('/api/servers/:id/restart',auth,async(req,res)=>{const s=getServer(req.params.id);if(!s||!isOwnerOrAdmin(req,s))return res.status(404).json({error:'Server not found'});if(!requireServerPerm(req,res,s,'restart'))return;await stopProcess(s);try{await startProcess(s);audit(req,'server.restart',{serverId:s.id});res.json({...s,metrics:await metrics(s)})}catch(e){res.status(400).json({error:e.message})}});
app.delete('/api/servers/:id',auth,async(req,res)=>{const s=getServer(req.params.id);if(!s||!isOwnerOrAdmin(req,s))return res.status(404).json({error:'Server not found'});await stopProcess(s,true);fs.rmSync(path.join(SERVERS_DIR,s.id),{recursive:true,force:true});audit(req,'server.delete',{serverId:s.id});broadcast({type:'server:deleted',id:s.id});res.json({message:'Server deleted.'})});
app.post('/api/servers/:id/command',auth,(req,res)=>{const s=getServer(req.params.id);if(!s||!isOwnerOrAdmin(req,s))return res.status(404).json({error:'Server not found'});if(!requireServerPerm(req,res,s,'console'))return;const c=processes.get(s.id);if(!c)return res.status(409).json({error:'Server is not running.'});const command=String(req.body.command||'').replace(/[\r\n]/g,'');if(!command)return res.status(400).json({error:'Command required'});try{c.stdin.write(command+'\n');appendLog(s,`> ${command}\n`);res.json({message:'Command sent.'})}catch(e){res.status(500).json({error:e.message})}});


app.get('/api/servers/:id/properties',auth,(req,res)=>{const s=getServer(req.params.id);if(!s||!isOwnerOrAdmin(req,s))return res.status(404).json({error:'Server not found'});res.json(readProperties(path.join(SERVERS_DIR,s.id,'server.properties')))});
app.put('/api/servers/:id/properties',auth,(req,res)=>{const s=getServer(req.params.id);if(!s||!isOwnerOrAdmin(req,s))return res.status(404).json({error:'Server not found'});if(processes.has(s.id))return res.status(409).json({error:'Stop the server before editing server.properties.'});const b=req.body;if(!b||typeof b!=='object'||Array.isArray(b))return res.status(400).json({error:'Properties object required'});const clean={};for(const [k,v] of Object.entries(b)){if(!/^[a-zA-Z0-9_.-]{1,80}$/.test(k))return res.status(400).json({error:`Invalid property: ${k}`});clean[k]=String(v).slice(0,1000)};writeProperties(path.join(SERVERS_DIR,s.id,'server.properties'),clean);res.json(clean)});
app.post('/api/servers/:id/minecraft/action',auth,(req,res)=>{const s=getServer(req.params.id);if(!s||!isOwnerOrAdmin(req,s))return res.status(404).json({error:'Server not found'});const {action,value}=req.body||{};const simple={save:'save-all',saveOn:'save-on',saveOff:'save-off',whitelistOn:'whitelist on',whitelistOff:'whitelist off',whitelistList:'whitelist list',reload:'reload',list:'list',weatherClear:'weather clear',weatherRain:'weather rain',weatherThunder:'weather thunder',timeDay:'time set day',timeNight:'time set night',difficultyPeaceful:'difficulty peaceful',difficultyEasy:'difficulty easy',difficultyNormal:'difficulty normal',difficultyHard:'difficulty hard'};let cmd=simple[action];if(action==='say')cmd=`say ${String(value||'').slice(0,300)}`;if(action==='whitelistAdd')cmd=`whitelist add ${String(value||'').replace(/[^a-zA-Z0-9_]/g,'').slice(0,16)}`;if(action==='whitelistRemove')cmd=`whitelist remove ${String(value||'').replace(/[^a-zA-Z0-9_]/g,'').slice(0,16)}`;if(action==='op')cmd=`op ${String(value||'').replace(/[^a-zA-Z0-9_]/g,'').slice(0,16)}`;if(action==='deop')cmd=`deop ${String(value||'').replace(/[^a-zA-Z0-9_]/g,'').slice(0,16)}`;if(action==='gamemode')cmd=`gamemode ${String(value||'survival').replace(/[^a-zA-Z]/g,'').slice(0,20)}`;if(action==='difficulty')cmd=`difficulty ${String(value||'normal').replace(/[^a-zA-Z]/g,'').slice(0,20)}`;if(!cmd)return res.status(400).json({error:'Unknown Minecraft action.'});try{mcCommand(s,cmd);res.json({message:'Command sent',command:cmd})}catch(e){res.status(409).json({error:e.message})}});


app.post('/api/servers/:id/files/upload',auth,express.raw({type:'application/octet-stream',limit:'50mb'}),(req,res)=>{
  try{const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,sv,'files'))return;const rel=safeRelative(req.headers['x-file-path']);if(!rel)return res.status(400).json({error:'X-File-Path required'});const p=resolveServerPath(sv,rel); const lim=userLimits(findUser(sv.owner)); const current=diskUsage(serverDirFor(sv)); const oldSize=fs.existsSync(p)?fs.statSync(p).size:0; if(current-oldSize+req.body.length>lim.maxDiskMB*1024*1024)return res.status(413).json({error:`Disk quota exceeded. Limit: ${lim.maxDiskMB} MB.`}); fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,req.body);audit(req,'file.upload',{serverId:sv.id,path:rel,size:req.body.length});res.json({message:'Uploaded.',size:req.body.length})}
  catch(e){res.status(400).json({error:e.message})}
});
app.get('/api/servers/:id/files',auth,(req,res)=>{
  try{const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).json({error:'Server not found'});if(!requireServerPerm(req,res,sv,'files'))return;
    const dir=resolveServerPath(sv,req.query.path||''); const st=fs.statSync(dir); if(!st.isDirectory())return res.status(400).json({error:'Not a directory'});
    const items=fs.readdirSync(dir,{withFileTypes:true}).map(e=>{const p=path.join(dir,e.name),x=fs.statSync(p);return {name:e.name,type:e.isDirectory()?'directory':'file',size:e.isDirectory()?0:x.size,modifiedAt:x.mtime.toISOString()}});
    res.json({path:safeRelative(req.query.path||''),items});
  }catch(e){res.status(400).json({error:e.message})}
});
app.get('/api/servers/:id/files/download',auth,(req,res)=>{
  try{const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,sv,'files'))return;const p=resolveServerPath(sv,req.query.path);if(!fs.statSync(p).isFile())return res.status(400).end();res.download(p,path.basename(p))}
  catch{res.status(404).end()}
});
app.get('/api/servers/:id/files/read',auth,(req,res)=>{
  try{const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,sv,'files'))return;const p=resolveServerPath(sv,req.query.path);const st=fs.statSync(p);if(!st.isFile()||st.size>2*1024*1024)return res.status(400).json({error:'File is not a readable text file or is too large.'});res.json({content:fs.readFileSync(p,'utf8')})}
  catch(e){res.status(400).json({error:e.message})}
});
app.put('/api/servers/:id/files',auth,(req,res)=>{
  try{const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).json({error:'Server not found'});if(!requireServerPerm(req,res,sv,'files'))return;const rel=safeRelative(req.body.path);if(!rel)return res.status(400).json({error:'Path required'});const p=resolveServerPath(sv,rel);const parent=path.dirname(p);fs.mkdirSync(parent,{recursive:true});if(req.body.type==='directory')fs.mkdirSync(p,{recursive:false});else{if(typeof req.body.content!=='string')return res.status(400).json({error:'Text content required'});if(Buffer.byteLength(req.body.content)>2*1024*1024)return res.status(413).json({error:'File too large'});fs.writeFileSync(p,req.body.content)}res.json({message:'Created.'})}
  catch(e){res.status(400).json({error:e.message})}
});
app.patch('/api/servers/:id/files',auth,(req,res)=>{
  try{const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,sv,'files'))return;const from=resolveServerPath(sv,req.body.path),to=resolveServerPath(sv,req.body.newPath);fs.renameSync(from,to);res.json({message:'Renamed.'})}catch(e){res.status(400).json({error:e.message})}
});
app.delete('/api/servers/:id/files',auth,(req,res)=>{
  try{const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,sv,'files'))return;const p=resolveServerPath(sv,req.body.path);if(p===serverDirFor(sv))return res.status(400).json({error:'Cannot delete server root'});fs.rmSync(p,{recursive:true,force:true});res.json({message:'Deleted.'})}catch(e){res.status(400).json({error:e.message})}
});
app.post('/api/servers/:id/backups',auth,async(req,res)=>{
  const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).json({error:'Server not found'});if(!requireServerPerm(req,res,sv,'backups'))return;
  try{const b=await createBackup(sv);audit(req,'backup.create',{serverId:sv.id,name:b.name});res.status(201).json(b)}catch(e){res.status(500).json({error:e.message})}
});
app.get('/api/servers/:id/backups',auth,(req,res)=>{const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).json({error:'Server not found'});if(!requireServerPerm(req,res,sv,'backups'))return;res.json(listBackups(sv))});
app.get('/api/servers/:id/backups/:name/download',auth,(req,res)=>{
  const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,sv,'backups'))return;const name=path.basename(req.params.name);if(!name.startsWith(sv.id+'-')||!name.endsWith('.tar.gz'))return res.status(400).end();res.download(path.join(BACKUPS_DIR,name),name);
});
app.post('/api/servers/:id/backups/:name/restore',auth,async(req,res)=>{
  const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).json({error:'Server not found'});if(!requireServerPerm(req,res,sv,'backups'))return;const name=path.basename(req.params.name);
  if(!name.startsWith(sv.id+'-')||!name.endsWith('.tar.gz'))return res.status(400).json({error:'Invalid backup'});
  try{const archive=path.join(BACKUPS_DIR,name);const entries=await new Promise((resolve,reject)=>execFile('tar',['-tzf',archive],{timeout:120000,maxBuffer:8*1024*1024},(e,stdout)=>e?reject(e):resolve(stdout)));const root=sv.id+'/';for(const raw of String(entries).split(/\r?\n/).filter(Boolean)){const n=raw.replace(/\\/g,'/');if(!n.startsWith(root)||n.includes('../')||n.startsWith('/')||n.split('/').includes('..'))throw new Error('Unsafe backup archive path.');}await stopProcess(sv);fs.rmSync(serverDirFor(sv),{recursive:true,force:true});fs.mkdirSync(SERVERS_DIR,{recursive:true});await new Promise((resolve,reject)=>execFile('tar',['-xzf',archive,'-C',SERVERS_DIR,'--no-same-owner'],{timeout:30*60*1000},e=>e?reject(e):resolve()));res.json({message:'Backup restored. Server is stopped.'})}
  catch(e){res.status(500).json({error:'Restore failed: '+e.message})}
});
app.delete('/api/servers/:id/backups/:name',auth,(req,res)=>{
  const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,sv,'backups'))return;const name=path.basename(req.params.name);if(!name.startsWith(sv.id+'-'))return res.status(400).end();fs.rmSync(path.join(BACKUPS_DIR,name),{force:true});audit(req,'backup.delete',{serverId:sv.id,name});res.json({message:'Backup deleted.'});
});
app.get('/api/servers/:id/schedules',auth,(req,res)=>{const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,sv,'schedules'))return;res.json(schedulesDb().schedules.filter(x=>x.serverId===sv.id))});
app.post('/api/servers/:id/schedules',auth,(req,res)=>{
  const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,sv,'schedules'))return;const {cron:expr,action,value,enabled=true}=req.body||{};
  if(typeof expr!=='string'||!cron.validate(expr)||!['start','stop','restart','command','backup'].includes(action))return res.status(400).json({error:'Invalid cron or action.'});
  if(action==='command' && !String(value||'').trim())return res.status(400).json({error:'Command required.'});
  const db=schedulesDb(),job={id:crypto.randomBytes(8).toString('hex'),serverId:sv.id,cron:expr,action,value:String(value||''),enabled:Boolean(enabled),createdAt:new Date().toISOString()};db.schedules.push(job);saveSchedules(db);refreshScheduleJobs();audit(req,'schedule.create',{serverId:sv.id,scheduleId:job.id,cron:job.cron,action:job.action});res.status(201).json(job);
});
app.patch('/api/servers/:id/schedules/:sid',auth,(req,res)=>{
  const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,sv,'schedules'))return;const db=schedulesDb(),j=db.schedules.find(x=>x.id===req.params.sid&&x.serverId===sv.id);if(!j)return res.status(404).end();
  if(req.body.cron!==undefined){if(!cron.validate(String(req.body.cron)))return res.status(400).json({error:'Invalid cron'});j.cron=String(req.body.cron)}if(req.body.enabled!==undefined)j.enabled=Boolean(req.body.enabled);if(req.body.action!==undefined&&['start','stop','restart','command','backup'].includes(req.body.action))j.action=req.body.action;if(req.body.value!==undefined)j.value=String(req.body.value);saveSchedules(db);refreshScheduleJobs();audit(req,'schedule.update',{serverId:sv.id,scheduleId:j.id});res.json(j);
});
app.delete('/api/servers/:id/schedules/:sid',auth,(req,res)=>{const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,sv,'schedules'))return;const db=schedulesDb();db.schedules=db.schedules.filter(x=>!(x.id===req.params.sid&&x.serverId===sv.id));saveSchedules(db);refreshScheduleJobs();audit(req,'schedule.delete',{serverId:sv.id,scheduleId:req.params.sid});res.json({message:'Schedule deleted.'})});

app.get('/api/servers/:id/startup',auth,(req,res)=>{const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,sv,'startup'))return;res.json(startupConfig(sv))});
app.put('/api/servers/:id/startup',auth,(req,res)=>{
  const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,sv,'startup'))return;if(processes.has(sv.id))return res.status(409).json({error:'Stop the server before changing startup settings.'});
  const b=req.body||{}, owner=findUser(sv.owner), lim=userLimits(owner), max=Number(lim.maxMemoryMB);const mem=Number(b.memoryMB);if(!Number.isInteger(mem)||mem<512||mem>max)return res.status(400).json({error:`Memory must be 512-${max} MB.`});
  if(typeof b.javaPath!=='string'||!b.javaPath.trim()||typeof b.jar!=='string'||!/^[a-zA-Z0-9_.-]+\.jar$/.test(b.jar))return res.status(400).json({error:'Invalid Java path or JAR.'});
  const flags=Array.isArray(b.jvmFlags)?b.jvmFlags.map(String).filter(x=>x.length<200).slice(0,30):[];const cpu=Number(b.cpuLimitPercent||100);if(!Number.isFinite(cpu)||cpu<1||cpu>Number(lim.maxCpuPercent))return res.status(400).json({error:`CPU limit must be 1-${lim.maxCpuPercent}%.`});
  sv.memoryMB=mem;sv.javaPath=b.javaPath.trim();sv.jar=b.jar;sv.jvmFlags=flags;sv.cpuLimitPercent=cpu;sv.startCommand=`${sv.javaPath} -Xms${mem}M -Xmx${mem}M ${flags.join(' ')} -jar ${sv.jar} --nogui`;saveServer(sv);res.json(startupConfig(sv));
});
app.get('/api/servers/:id/resources',auth,(req,res)=>{const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,sv,'startup'))return;const m=getSettings().resources;res.json({memoryMB:sv.memoryMB,cpuLimitPercent:sv.cpuLimitPercent||100,maxMemoryMB:m.maxMemoryMB,maxCpuPercent:m.maxCpuPercent})});
app.put('/api/servers/:id/resources',auth,(req,res)=>{
  const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,sv,'startup'))return;if(processes.has(sv.id))return res.status(409).json({error:'Stop the server before changing resources.'});
  const max=userLimits(findUser(sv.owner)),mem=Number(req.body.memoryMB),cpu=Number(req.body.cpuLimitPercent);if(!Number.isInteger(mem)||mem<512||mem>Number(max.maxMemoryMB))return res.status(400).json({error:'Invalid memory limit'});if(!Number.isFinite(cpu)||cpu<1||cpu>Number(max.maxCpuPercent))return res.status(400).json({error:'Invalid CPU limit'});sv.memoryMB=mem;sv.cpuLimitPercent=cpu;sv.startCommand=`${sv.javaPath||'java'} -Xms${mem}M -Xmx${mem}M ${(sv.jvmFlags||[]).join(' ')} -jar ${sv.jar||'server.jar'} --nogui`;saveServer(sv);res.json(startupConfig(sv));
});
app.post('/api/servers/:id/players/action',auth,(req,res)=>{
  const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,sv,'players'))return;const {action,value}=req.body||{};
  const map={list:'list',save:'save-all',reload:'reload'};let cmd=map[action]||playerCmd(action,value);
  if(action==='say')cmd=`say ${String(value||'').slice(0,300)}`;
  if(!cmd)return res.status(400).json({error:'Unknown player action.'});
  try{mcCommand(sv,cmd);res.json({message:'Command sent',command:cmd})}catch(e){res.status(409).json({error:e.message})}
});
app.get('/api/servers/:id/players',auth,(req,res)=>{const sv=getServer(req.params.id);if(!sv||!(req.user.role==='admin'||sv.owner===req.user.sub||sv.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,sv,'players'))return;const h=extractMinecraftHealth(sv);res.json({online:processes.has(sv.id),players:h.players||{online:0,max:0,names:[]}})});


app.get('/api/servers/:id/permissions',auth,(req,res)=>{const s=getServer(req.params.id);if(!s||!isOwnerOrAdmin(req,s))return res.status(404).json({error:'Server not found'});res.json({owner:s.owner,permissions:s.permissions||{},available:SERVER_PERMS});});
app.put('/api/servers/:id/permissions',auth,(req,res)=>{const s=getServer(req.params.id);if(!s||!isOwnerOrAdmin(req,s))return res.status(404).json({error:'Server not found'});if(req.user.role!=='admin'&&s.owner!==req.user.sub)return res.status(403).json({error:'Owner or administrator required'});const username=String(req.body?.username||'');const u=findUser(username);if(!u)return res.status(404).json({error:'User not found'});if(u.username===s.owner)return res.status(400).json({error:'Owner permissions cannot be changed.'});s.permissions=s.permissions||{};s.permissions[u.username]=normalizePermissions(req.body?.permissions);saveServer(s);audit(req,'server.permissions',{serverId:s.id,username:u.username,permissions:s.permissions[u.username]});res.json(s.permissions[u.username]);});
app.delete('/api/servers/:id/permissions/:username',auth,(req,res)=>{const s=getServer(req.params.id);if(!s||!isOwnerOrAdmin(req,s))return res.status(404).json({error:'Server not found'});delete (s.permissions||{})[req.params.username];saveServer(s);audit(req,'server.permissions.remove',{serverId:s.id,username:req.params.username});res.json({message:'Permission removed.'});});
app.get('/api/admin/audit',auth,admin,(req,res)=>{
  const limit=Math.min(500,Math.max(1,Number(req.query.limit)||100));
  let lines=[]; try{lines=fs.readFileSync(AUDIT_FILE,'utf8').trim().split(/\r?\n/).filter(Boolean).slice(-limit).reverse().map(x=>{try{return JSON.parse(x)}catch{return null}}).filter(Boolean)}catch{}
  res.json(lines);
});
app.put('/api/admin/users/:username/limits',auth,admin,(req,res)=>{
  const u=findUser(req.params.username); if(!u)return res.status(404).json({error:'User not found'}); const r=getSettings().resources,b=req.body||{};
  const limits={maxServers:Math.max(0,Math.min(100,Number(b.maxServers ?? userLimits(u).maxServers))),maxMemoryMB:Math.max(512,Math.min(Number(r.maxMemoryMB),Number(b.maxMemoryMB ?? userLimits(u).maxMemoryMB))),maxDiskMB:Math.max(512,Math.min(Number(r.maxDiskMB),Number(b.maxDiskMB ?? userLimits(u).maxDiskMB))),maxCpuPercent:Math.max(1,Math.min(Number(r.maxCpuPercent),Number(b.maxCpuPercent ?? userLimits(u).maxCpuPercent)))};
  u.limits=limits; writeUser(u); audit(req,'admin.user.limits',{username:u.username,limits}); res.json(publicUser(u));
});
app.get('/api/admin/overview',auth,admin,async(req,res)=>{const servers=listServers();res.json({users:userDb().users.length,servers:servers.length,nodes:getSettings().nodes.length,online:servers.filter(s=>processes.has(s.id)).length})});
app.get('/api/admin/users',auth,admin,(req,res)=>res.json(userDb().users.map(publicUser)));
app.post('/api/admin/users',auth,admin,async(req,res)=>{const {fullName,username,email,password,role}=req.body||{};if(!safeName(fullName)||!validUsername(username)||!validEmail(email)||String(password||'').length<8)return res.status(400).json({error:'Invalid user data.'});const db=userDb();if(db.users.some(u=>u.username.toLowerCase()===username.toLowerCase()||u.email.toLowerCase()===email.toLowerCase()))return res.status(409).json({error:'Username or email is already in use.'});const u={fullName:safeName(fullName),username,email:email.toLowerCase(),passwordHash:await bcrypt.hash(password,12),role:role==='admin'?'admin':'user',limits:{maxServers:Number(req.body?.maxServers)||getSettings().resources.maxServersPerUser,maxMemoryMB:Number(req.body?.maxMemoryMB)||getSettings().resources.maxMemoryMB,maxDiskMB:Number(req.body?.maxDiskMB)||getSettings().resources.maxDiskMB,maxCpuPercent:Number(req.body?.maxCpuPercent)||getSettings().resources.maxCpuPercent},createdAt:new Date().toISOString()};writeUser(u);audit(req,'admin.user.create',{username:u.username,role:u.role});res.status(201).json(publicUser(u))});
app.delete('/api/admin/users/:username',auth,admin,async(req,res)=>{if(req.params.username===req.user.sub)return res.status(400).json({error:'You cannot delete your own admin account here.'});const u=findUser(req.params.username);if(!u)return res.status(404).json({error:'User not found'});for(const sv of listServers().filter(s=>s.owner===u.username)){await stopProcess(s,true);fs.rmSync(path.join(SERVERS_DIR,sv.id),{recursive:true,force:true})}const db=userDb();db.users=db.users.filter(x=>x.username!==u.username);saveDb(db);deleteUserFiles(u);res.json({message:'User deleted.'})});
app.get('/api/admin/servers',auth,admin,async(req,res)=>res.json(await Promise.all(listServers().map(async s=>({...s,metrics:await metrics(s)})))));
app.get('/api/servers/:id/metrics/history',auth,async(req,res)=>{const s=getServer(req.params.id);if(!s||!(req.user.role==='admin'||s.owner===req.user.sub||s.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,s,'console'))return;res.json(readJson(path.join(METRICS_DIR,`${s.id}.json`),[]));});
app.get('/api/servers/:id/health',auth,async(req,res)=>{const s=getServer(req.params.id);if(!s||!(req.user.role==='admin'||s.owner===req.user.sub||s.permissions?.[req.user.sub]))return res.status(404).end();if(!requireServerPerm(req,res,s,'console'))return;const m=await metrics(s);const java=detectJava();const lim=userLimits(findUser(s.owner));res.json({status:s.status,metrics:m,java,limits:lim,crashes:getCrashHistory(s).slice(0,20),cpuEnforcement:process.platform!=='win32'&&spawnSync('which',['cpulimit'],{encoding:'utf8'}).status===0});});
app.get('/api/admin/audit',auth,admin,(req,res)=>{const n=Math.max(1,Math.min(500,Number(req.query.limit)||100));let lines=[];try{lines=fs.readFileSync(AUDIT_FILE,'utf8').split(/\n/).filter(Boolean).slice(-n).reverse().map(x=>{try{return JSON.parse(x)}catch{return {raw:x}}});}catch{}res.json(lines);});
app.get('/api/admin/system',auth,admin,async(req,res)=>{const total=os.totalmem(),free=os.freemem(),disk=diskUsage(ROOT),load=os.loadavg();res.json({platform:process.platform,node:process.version,uptime:os.uptime(),load,memory:{total,free,used:total-free},disk:{used:disk},network:systemNetwork(),cpus:os.cpus().length,servers:listServers().length,running:listServers().filter(s=>processes.has(s.id)).length});});

app.put('/api/admin/settings',auth,admin,(req,res)=>{const cur=getSettings(), b=req.body||{};const next={...cur};if(typeof b.panelName==='string'&&b.panelName.trim())next.panelName=safeName(b.panelName);if(typeof b.registrationEnabled==='boolean')next.registrationEnabled=b.registrationEnabled;if(typeof b.useCustomImage==='boolean')next.useCustomImage=b.useCustomImage;if(b.minecraft&&typeof b.minecraft==='object')next.minecraft={...cur.minecraft,...b.minecraft};if(b.recovery&&typeof b.recovery==='object')next.recovery={...cur.recovery,autoRestart:Boolean(b.recovery.autoRestart),maxAttempts:Math.max(0,Math.min(20,Number(b.recovery.maxAttempts)||3)),delaySeconds:Math.max(1,Math.min(3600,Number(b.recovery.delaySeconds)||10))};if(b.resources)next.resources={...cur.resources,...Object.fromEntries(Object.entries(b.resources).filter(([k,v])=>Number.isFinite(Number(v))&&Number(v)>0).map(([k,v])=>[k,Number(v)]))};saveSettings(next);res.json(next)});
app.post('/api/admin/logo',auth,admin,(req,res)=>{const {data}=req.body||{};if(typeof data!=='string'||!/^data:image\/(png|jpeg|webp|gif);base64,[A-Za-z0-9+/=\s]+$/.test(data)||data.length>1400000)return res.status(400).json({error:'Invalid or oversized image.'});const m=data.match(/^data:image\/(png|jpeg|webp|gif);base64,/);const ext=m[1]==='jpeg'?'jpg':m[1];const file=`custom-logo.${ext}`;fs.writeFileSync(path.join(PUBLIC_DIR,file),Buffer.from(data.slice(m[0].length),'base64'));const s=getSettings();s.logoPath='/'+file;s.useCustomImage=true;saveSettings(s);res.json(s)});
app.get('/api/admin/nodes',auth,admin,async(req,res)=>{
  const nodes=getSettings().nodes.map(n=>n.id==='local'
    ? {...n,ramUsed:os.totalmem()-os.freemem(),ramTotal:os.totalmem(),load:os.loadavg(),uptime:os.uptime(),online:true,diskBytes:diskUsage(ROOT)}
    : {...n,online:false});
  res.json(nodes);
});
app.post('/api/admin/nodes',auth,admin,(req,res)=>{const b=req.body||{};if(!b.name||!b.address)return res.status(400).json({error:'Node name and address are required'});const s=getSettings();const n={id:crypto.randomBytes(6).toString('hex'),name:safeName(b.name),ramGB:Number(b.ram)||0,diskGB:Number(b.disk)||0,cores:Number(b.cores)||1,daemonPort:Number(b.daemonPort)||0,address:String(b.address),location:String(b.location||''),local:false};s.nodes.push(n);saveSettings(s);res.status(201).json(n)});

app.get('*',(req,res)=>res.sendFile(path.join(PUBLIC_DIR,'Login.html')));

server.on('upgrade',(req,socket,head)=>{
  const origin=req.headers.origin; const allowed=process.env.ALLOWED_ORIGIN; if(origin&&allowed&&origin!==allowed){socket.destroy();return;}
  if(req.url.startsWith('/ws')) wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req)); else socket.destroy();
});
wss.on('connection',(ws,req)=>{
  let serverId=null, authed=false; const authTimer=setTimeout(()=>{if(!authed)try{ws.close(1008,'Authentication timeout')}catch{}},10000);
  ws.on('message',async raw=>{
    try{
      const m=JSON.parse(raw.toString());
      if(m.type==='auth'){const payload=jwt.verify(String(m.token||''),SECRET);const s=getServer(String(m.serverId||''));if(!s||!(payload.role==='admin'||s.owner===payload.sub||s.permissions?.[payload.sub]?.console))throw new Error('Forbidden');serverId=s.id;authed=true;clearTimeout(authTimer);ws.user=payload.sub;ws.role=payload.role;(sockets.get(serverId)||sockets.set(serverId,new Set()).get(serverId)).add(ws);ws.send(JSON.stringify({type:'ready',server:s,metrics:await metrics(s)}));const log=path.join(SERVERS_DIR,s.id,'runtime.log');if(fs.existsSync(log))ws.send(JSON.stringify({type:'output',data:fs.readFileSync(log,'utf8').slice(-100000)}));return}
      if(!authed)throw new Error('Authenticate first');
      if(m.type==='command'){const c=processes.get(serverId);if(!c)throw new Error('Server is not running');const cmd=String(m.command||'').replace(/[\r\n]/g,'');if(!cmd) return;c.stdin.write(cmd+'\n');appendLog(getServer(serverId),`> ${cmd}\n`);}
    }catch(e){ws.send(JSON.stringify({type:'error',error:e.message}))}
  });
  ws.on('close',()=>{clearTimeout(authTimer);if(serverId&&sockets.has(serverId)){sockets.get(serverId).delete(ws);if(!sockets.get(serverId).size)sockets.delete(serverId)}});
});

setInterval(async()=>{
  for(const s of listServers()) {
    if(processes.has(s.id)) sendServer(s.id,{type:'metrics',metrics:await metrics(s)});
  }
},2000);

refreshScheduleJobs();
server.listen(PORT,HOST,()=>console.log(`HeronPanel listening on http://${HOST}:${PORT}`));
process.on('SIGTERM',async()=>{for(const s of listServers()) if(processes.has(s.id)) await stopProcess(s,true);server.close(()=>process.exit(0));});
